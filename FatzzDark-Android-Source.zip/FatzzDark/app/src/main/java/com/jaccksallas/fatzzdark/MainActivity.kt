package com.jaccksallas.fatzzdark

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay
import java.util.concurrent.Executor

private val Bg = Color(0xFF090B10)
private val Surface = Color(0xFF151923)
private val Surface2 = Color(0xFF202633)
private val Accent = Color(0xFFB7F36B)
private val Muted = Color(0xFF9AA3B2)
private val ArtColors = listOf(Color(0xFF244B72), Color(0xFFB35B91))

private data class AudioTrack(val uri: String, val title: String, val artist: String = "Local audio")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FatzzApp() }
    }
}

@Composable
private fun FatzzApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("fatzz_library", Context.MODE_PRIVATE) }
    var tracks by remember { mutableStateOf(loadTracks(prefs)) }
    var liked by remember { mutableStateOf(prefs.getStringSet("liked", emptySet())?.toSet() ?: emptySet()) }
    var selectedTab by remember { mutableStateOf("Home") }
    var search by remember { mutableStateOf("") }
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var currentTitle by remember { mutableStateOf("Choose a song") }
    var currentArtist by remember { mutableStateOf("Import audio from your device") }
    var duration by remember { mutableLongStateOf(0L) }
    var position by remember { mutableLongStateOf(0L) }
    var currentUri by remember { mutableStateOf<String?>(null) }

    DisposableEffect(context) {
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future: ListenableFuture<MediaController> = MediaController.Builder(context, token).buildAsync()
        val executor: Executor = ContextCompat.getMainExecutor(context)
        future.addListener({
            runCatching {
                val c = future.get()
                controller = c
                fun refresh() {
                    isPlaying = c.isPlaying
                    currentTitle = c.mediaMetadata.title?.toString() ?: "Choose a song"
                    currentArtist = c.mediaMetadata.artist?.toString() ?: "Local audio"
                    currentUri = c.currentMediaItem?.localConfiguration?.uri?.toString()
                    duration = c.duration.coerceAtLeast(0L)
                    position = c.currentPosition.coerceAtLeast(0L)
                }
                c.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(playing: Boolean) = refresh()
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = refresh()
                    override fun onPlaybackStateChanged(playbackState: Int) = refresh()
                    override fun onMediaMetadataChanged(mediaMetadata: MediaMetadata) = refresh()
                })
                refresh()
            }
        }, executor)
        onDispose {
            controller = null
            MediaController.releaseFuture(future)
        }
    }

    LaunchedEffect(controller, isPlaying) {
        while (controller != null) {
            val c = controller
            if (c != null) {
                position = c.currentPosition.coerceAtLeast(0L)
                duration = c.duration.coerceAtLeast(0L)
                isPlaying = c.isPlaying
            }
            delay(if (isPlaying) 500 else 1000)
        }
    }

    val notificationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val added = uris.mapNotNull { uri ->
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                AudioTrack(uri.toString(), queryDisplayName(context, uri))
            }.getOrNull()
        }
        if (added.isNotEmpty()) {
            val merged = (tracks + added).distinctBy { it.uri }
            tracks = merged
            saveTracks(prefs, merged)
            val firstAddedIndex = merged.indexOfFirst { it.uri == added.first().uri }.coerceAtLeast(0)
            playTrackList(controller, merged, firstAddedIndex)
        }
    }

    val importAudio: () -> Unit = { pickAudio.launch(arrayOf("audio/*")) }

    fun pickAndPlay(track: AudioTrack) {
        val index = tracks.indexOfFirst { it.uri == track.uri }
        if (index >= 0) playTrackList(controller, tracks, index)
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Surface, primary = Accent, onPrimary = Color(0xFF11150B),
        onBackground = Color.White, onSurface = Color.White, secondary = Muted
    )) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                Column {
                    MiniPlayer(
                        title = currentTitle, artist = currentArtist, playing = isPlaying,
                        onPrevious = { controller?.seekToPreviousMediaItem() },
                        onToggle = { controller?.let { if (it.isPlaying) it.pause() else if (it.mediaItemCount > 0) it.play() } },
                        onNext = { controller?.seekToNextMediaItem() },
                        position = position, duration = duration,
                        onSeek = { target -> controller?.seekTo(target) }
                    )
                    NavigationBar(containerColor = Color(0xFF10141C), tonalElevation = 0.dp) {
                        listOf(Triple("Home", Icons.Default.Home, "Home"), Triple("Search", Icons.Default.Search, "Search"), Triple("Library", Icons.Default.LibraryMusic, "Library")).forEach { (label, icon, route) ->
                            NavigationBarItem(selected = selectedTab == route, onClick = { selectedTab = route },
                                icon = { Icon(icon, contentDescription = label) }, label = { Text(label) },
                                colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, selectedTextColor = Accent,
                                    indicatorColor = Surface2, unselectedIconColor = Muted, unselectedTextColor = Muted))
                        }
                    }
                }
            }
        ) { padding ->
            when (selectedTab) {
                "Search" -> SearchScreen(Modifier.padding(padding), search, { search = it }, tracks, ::pickAndPlay, importAudio)
                "Library" -> LibraryScreen(Modifier.padding(padding), tracks, liked, ::pickAndPlay,
                    { uri -> liked = liked - uri; prefs.edit().putStringSet("liked", liked).apply() }, importAudio)
                else -> HomeScreen(Modifier.padding(padding), tracks, liked, currentUri, ::pickAndPlay,
                    { uri -> liked = if (uri in liked) liked - uri else liked + uri; prefs.edit().putStringSet("liked", liked).apply() }, importAudio)
            }
        }
    }
}

private fun playTrackList(controller: MediaController?, tracks: List<AudioTrack>, index: Int) {
    val c = controller ?: return
    if (tracks.isEmpty() || index !in tracks.indices) return
    val items = tracks.map { track ->
        MediaItem.Builder().setUri(Uri.parse(track.uri)).setMediaMetadata(
            MediaMetadata.Builder().setTitle(track.title).setArtist(track.artist).build()
        ).build()
    }
    c.setMediaItems(items, index, 0L)
    c.prepare()
    c.play()
}

private fun queryDisplayName(context: Context, uri: Uri): String {
    var name = "Audio track"
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
        if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
    }
    return name.substringBeforeLast('.', name).ifBlank { "Audio track" }
}

private fun loadTracks(prefs: android.content.SharedPreferences): List<AudioTrack> =
    prefs.getString("tracks", null)?.split("\n")?.mapNotNull { row ->
        val parts = row.split("|", limit = 2)
        if (parts.size == 2) AudioTrack(parts[0], parts[1]) else null
    } ?: emptyList()

private fun saveTracks(prefs: android.content.SharedPreferences, tracks: List<AudioTrack>) {
    prefs.edit().putString("tracks", tracks.joinToString("\n") { "${it.uri}|${it.title}" }).apply()
}

@Composable
private fun HomeScreen(modifier: Modifier, tracks: List<AudioTrack>, liked: Set<String>, currentUri: String?, onPick: (AudioTrack) -> Unit, onLike: (String) -> Unit, onImport: () -> Unit) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("GOOD EVENING", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Your sound,\nyour space.", fontSize = 31.sp, lineHeight = 35.sp, fontWeight = FontWeight.ExtraBold)
                }
                Box(Modifier.size(42.dp).clip(CircleShape).background(Surface2), contentAlignment = Alignment.Center) { Icon(Icons.Default.GraphicEq, null, tint = Accent) }
            }
        }
        item {
            Box(Modifier.fillMaxWidth().height(178.dp).clip(RoundedCornerShape(24.dp))
                .background(Brush.linearGradient(listOf(Color(0xFF334C59), Color(0xFF7A4D65), Color(0xFF20263B))))
                .clickable(onClick = onImport).padding(20.dp)) {
                Column(Modifier.align(Alignment.BottomStart)) {
                    Text("YOUR OFFLINE LIBRARY", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Bring your\nnight to life", fontSize = 28.sp, lineHeight = 31.sp, fontWeight = FontWeight.ExtraBold)
                }
                Icon(Icons.Default.AddCircle, null, tint = Color.White, modifier = Modifier.align(Alignment.BottomEnd).size(42.dp))
            }
        }
        item { SectionTitle("Your music", "${tracks.size} TRACKS") }
        if (tracks.isEmpty()) item { EmptyLibrary(onImport) }
        items(tracks) { track -> TrackRow(track, track.uri == currentUri, track.uri in liked, { onPick(track) }, { onLike(track.uri) }) }
    }
}

@Composable
private fun SearchScreen(modifier: Modifier, query: String, onQuery: (String) -> Unit, tracks: List<AudioTrack>, onPick: (AudioTrack) -> Unit, onImport: () -> Unit) {
    val results = tracks.filter { it.title.contains(query, true) }
    Column(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 22.dp)) {
        Text("Search", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text("Find a track in your device library.", color = Muted)
        Spacer(Modifier.height(18.dp))
        OutlinedTextField(value = query, onValueChange = onQuery, modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Search your songs") }, leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent,
                unfocusedBorderColor = Surface2, focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Accent), singleLine = true)
        Spacer(Modifier.height(18.dp))
        if (results.isEmpty()) EmptyLibrary(onImport) else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(results) { TrackRow(it, false, false, { onPick(it) }, {}) }
        }
    }
}

@Composable
private fun LibraryScreen(modifier: Modifier, tracks: List<AudioTrack>, liked: Set<String>, onPick: (AudioTrack) -> Unit, onUnlike: (String) -> Unit, onImport: () -> Unit) {
    val saved = tracks.filter { it.uri in liked }
    Column(modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 22.dp)) {
        Text("Your Library", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
        Text("The tracks you keep close.", color = Muted)
        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surface).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Color(0xFF6B4F9A), Accent))), contentAlignment = Alignment.Center) { Icon(Icons.Default.Favorite, null, tint = Color.White) }
            Spacer(Modifier.width(14.dp)); Column { Text("Liked songs", fontWeight = FontWeight.Bold); Text("${saved.size} tracks", color = Muted, fontSize = 12.sp) }
        }
        Spacer(Modifier.height(18.dp))
        if (saved.isEmpty()) EmptyLibrary(onImport)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(saved) { TrackRow(it, false, true, { onPick(it) }, { onUnlike(it.uri) }) } }
    }
}

@Composable
private fun EmptyLibrary(onImport: () -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Surface).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(Icons.Default.LibraryMusic, null, tint = Accent, modifier = Modifier.size(32.dp))
        Spacer(Modifier.height(8.dp)); Text("Your library is waiting", fontWeight = FontWeight.Bold)
        Text("Choose audio files stored on your device.", color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(12.dp)); Button(onClick = onImport, colors = ButtonDefaults.buttonColors(containerColor = Accent, contentColor = Color.Black)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Import audio") }
    }
}

@Composable
private fun TrackRow(track: AudioTrack, selected: Boolean, liked: Boolean, onClick: () -> Unit, onLike: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (selected) Surface2 else Color.Transparent)
        .clickable(onClick = onClick).padding(vertical = 9.dp, horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        AlbumArt(Modifier.size(54.dp)); Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(track.title, fontWeight = FontWeight.SemiBold, color = if (selected) Accent else Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("Local audio", color = Muted, fontSize = 12.sp)
        }
        if (liked) IconButton(onClick = onLike) { Icon(Icons.Default.Favorite, null, tint = Accent) }
        else IconButton(onClick = onLike) { Icon(Icons.Default.FavoriteBorder, null, tint = Muted) }
    }
}

@Composable
private fun AlbumArt(modifier: Modifier = Modifier) {
    Box(modifier.clip(RoundedCornerShape(13.dp)).background(Brush.linearGradient(ArtColors)), contentAlignment = Alignment.Center) {
        Icon(Icons.Default.GraphicEq, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(25.dp))
    }
}

@Composable
private fun MiniPlayer(title: String, artist: String, playing: Boolean, onPrevious: () -> Unit, onToggle: () -> Unit, onNext: () -> Unit, position: Long, duration: Long, onSeek: (Long) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp).clip(RoundedCornerShape(15.dp)).background(Surface2).padding(horizontal = 10.dp, vertical = 7.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(Modifier.size(42.dp)); Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis); Text(artist, color = Muted, fontSize = 11.sp) }
            IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, null, tint = Color.White) }
            IconButton(onClick = onToggle) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Accent) }
            IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, null, tint = Color.White) }
        }
        if (duration > 0L) {
            Slider(value = position.coerceIn(0L, duration).toFloat(), onValueChange = { onSeek(it.toLong()) },
                valueRange = 0f..duration.toFloat(), modifier = Modifier.fillMaxWidth().height(18.dp),
                colors = SliderDefaults.colors(thumbColor = Accent, activeTrackColor = Accent, inactiveTrackColor = Muted))
        }
    }
}

@Composable
private fun SectionTitle(title: String, action: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
        Text(action, color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
    }
}
